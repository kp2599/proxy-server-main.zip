#!/bin/sh 
docker run --name server-proxy -d --restart unless-stopped -e CONNECTION_ID=$1 -e TOKEN=$2 -e DNS=$3 -e LOG=$4 -p 8888:8888 -p 8080:8080 server-proxy
