# Build Image
To build docker image run ./build.sh  
or run jenkins proxy-server pipeline

# Run Container
To run the container successfully, you need to pass 4 environment variables in specified sequency
./run.sh CONNECTION_ID TOKEN DNS LOG  
e.g. ./run.sh 101 xyz abc.com quiet  

or Add ENV in kubernetes manifest file

CONNECTION_ID -> id assigned while inserting entry in db  
TOKEN -> Authentication token  
DNS -> registrar endpoint  
LOG -> if you don't want logs pass 'quiet' and verbose for logs

# Ports  
1. proxy server listen on 8080  
2. websocket server listen on 8888
3. /health api on port 8082 for healthcheck
