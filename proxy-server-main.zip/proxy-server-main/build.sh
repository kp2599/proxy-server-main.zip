#!/bin/sh 
docker build . -t server-proxy
