const io = require("socket.io")();
const net = require("net");
const axios = require("axios");
const server = net.createServer();

//HealthCheck
const http = require("http");

const serverHel = http.createServer((req, res) => {
  if (req.url === "/health") {
    console.log("Healthcheck endpoint hit");
    res.writeHead(200);
    res.end("Health : The app is running ");
  } else {
    res.writeHead(404);
    res.end();
  }
});
serverHel.listen(8082);

const transactions = {};

const connection_id = process.env.CONNECTION_ID;
const arg_log = process.env.LOG;
const dns = process.env.DNS;
const token = process.env.TOKEN;

function log(msg) {
  if (arg_log != "quiet") console.log(msg);
}

if (!connection_id) {
  log("Missing: Connection ID");
} else {
  try {
    var generateTransactionId = (length) => {
      let result = "";
      const characters =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      const charactersLength = characters.length;
      for (let i = 0; i < length; i += 1) {
        result += characters.charAt(
          Math.floor(Math.random() * charactersLength)
        );
      }
      return result;
    };
  } catch (error) {
    log(error.message);
  }
  try {
    io.on("connection", function (webSocket) {
      try {
        log("Client Connected");
        server.on("connection", (proxySocket) => {
          proxySocket.once("data", (data) => {
            try {
              const transId = generateTransactionId(32);
              log(`[${transId}] init data ${data.toString()}`);

              webSocket.on(`${"event"}-${transId}`, (data) => {
                log(`[${transId}] receiving data`);
                try {
                  proxySocket.write(data);
                } catch (error) {
                  log(`this is the error [${error}]`);
                }
              });

              log(`[${transId}] emitting data`);
              webSocket.emit("event", { data, transId });

              proxySocket.on("close", (data) => {
                try {
                  webSocket.emit(`close`, { transId });
                  log(`[${transId}] CLOSED`);
                } catch (error) {
                  log(`new error [${error}]`);
                }
              });

              proxySocket.on("data", (data) => {
                log(`[${transId}] re-emitting data`);

                webSocket.emit("event", { data, transId });
              });
            } catch (error) {
              log(error.message);
            }
          });
        });
        webSocket.on("disconnect", () => {
          log("Client disconnected");
          try {
            log("notifying registrar...");
            axios.put(
              `https://${dns}/registrar/api/inactive/${connection_id}`,
              {},
              {
                headers: {
                  "Content-Type": "application/json",
                  Authorization: token,
                },
              }
            );
            log("notified registrar successfully");
          } catch (error) {
            log(error.message);
          }
        });
      } catch (error) {
        log(error.message);
      }
    });
  } catch (error) {
    log(error.message);
  }

  io.listen(8888);
  log("webSocket server Listening on *:8888");

  server.listen(
    {
      host: "0.0.0.0",
      port: 8080,
    },
    () => {
      log("Proxy Server listening on 0.0.0.0:8080");
    }
  );
}
